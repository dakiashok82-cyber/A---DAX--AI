# A-DAX AI — self-hosted backend (optional)

The A-DAX page (public/index.html) works on its own as a Claude artifact for chat, Story-to-Video planning, prompts, memory and browser voice.
This backend adds what a browser page cannot do safely by itself: **image generation, voice-over audio files, web search**, and chat outside Claude.
API keys live only in server environment variables — never in the page.

## Run it
1. Install Node 18+. In this folder run: `node server.js` (no npm install needed).
2. Set environment variables first (see .env.example). Example (Mac/Linux):
   `ANTHROPIC_API_KEY=... OPENAI_API_KEY=... BRAVE_API_KEY=... ACCESS_TOKEN=mypass node server.js`
3. Open http://localhost:3000 on the same computer.

## Use it on an Android phone
Chrome only allows the microphone on **https** pages (or localhost on that same device), so a plain http://192.168.x.x address will block voice input.
- Easiest: deploy this folder to a host that gives you https (Render, Railway, Fly.io, etc.): start command `node server.js`, add the environment variables in the host's dashboard.
- Or tunnel your computer with an https tunnel (Cloudflare Tunnel, ngrok) and open that https URL on the phone.
Then open the https URL in **Chrome on Android**, allow the microphone when asked, and in A-DAX **Settings** enter your ACCESS_TOKEN and tap *Save token & re-check*. Settings shows which services are connected.

## Notes and limits
- Not tested against the live provider APIs here (no network access in the build environment): check your accounts, model names and billing. Change models with ANTHROPIC_MODEL, IMAGE_MODEL, TTS_MODEL.
- Providers charge per request. Keep ACCESS_TOKEN set so strangers can't spend your credits.
- TTS quality for Gujarati and Hindi depends on the provider; test before relying on it.
- Search uses the Brave Search API; you can swap in another provider in server.js.
